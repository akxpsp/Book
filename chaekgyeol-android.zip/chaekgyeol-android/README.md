# 북 리더 · 안드로이드(갤럭시) 앱

웹 버전 북 리더를 안드로이드 앱(APK)으로 만드는 프로젝트입니다.
앱으로 설치하면 웹페이지로는 할 수 없던 아래 기능이 켜집니다.

| 기능 | 웹페이지 | 이 앱 |
|---|---|---|
| 폰 저장소 폴더 탐색 (내 파일) | 폴더를 매번 직접 선택 | 내 저장공간·SD카드·다운로드 폴더를 바로 탐색, 마지막으로 연 폴더 기억 |
| 볼륨키로 페이지 넘기기 | 불가 | 책 읽는 중에만 동작 (그 밖에서는 평소처럼 볼륨 조절) |
| 시스템 알림줄 숨기기 | 전체 화면 요청(불안정) | 책 읽는 동안 상태표시줄 숨김 |
| 뒤로가기 | 브라우저 기록 | 앱 안에서 한 단계씩 뒤로, 서재에서 누르면 종료 |
| 백업 저장 | 다운로드 확인창 | 다운로드 폴더에 바로 저장 |
| PDF·ZIP 읽기 | 인터넷 필요 | 앱 안에 엔진 포함 (오프라인 가능) |

## 방법 A — PC에서 만들기 (Android Studio 필요)

1. Node.js 20 이상, JDK 21, Android Studio(SDK 포함) 설치
2. 이 폴더에서
   ```
   npm install
   npm run setup
   cd android
   ./gradlew assembleDebug        # Windows: gradlew.bat assembleDebug
   ```
3. `android/app/build/outputs/apk/debug/app-debug.apk` 가 만들어집니다.
   또는 `npx cap open android` 로 Android Studio를 열고 ▶ 실행(갤럭시를 USB로 연결).

## 방법 B — GitHub에서 자동으로 만들기 (PC에 아무것도 설치 안 해도 됨)

1. 이 폴더 전체를 본인 GitHub 저장소(비공개 가능)에 올립니다. (`node_modules`, `www`, `android` 폴더는 올리지 않습니다 — `.gitignore`에 이미 제외돼 있음)
2. 저장소의 **Actions → Build APK → Run workflow** 를 누릅니다. (올리기만 해도 자동 실행)
3. 5~10분 뒤 실행 결과 화면 맨 아래 **Artifacts → book-reader-apk** 를 내려받아 압축을 풀면 `app-debug.apk` 가 있습니다.

## 갤럭시에 설치

1. `app-debug.apk` 를 폰으로 옮깁니다 (카카오톡 나에게 보내기, 구글 드라이브, USB 등).
2. 파일을 누르면 **"출처를 알 수 없는 앱 설치"** 허용 화면이 나옵니다. 허용한 뒤 설치합니다. (Play 프로텍트 경고가 나오면 "무시하고 설치")
3. 앱을 열고 **메뉴(☰) → 내 파일** 에서 **"파일 접근 허용"** 을 누르면 설정 화면이 열립니다. **북 리더**를 켜고 돌아오면 폰 저장소가 보입니다.
4. 볼륨키: 책을 열고 **설정 → 볼륨키** 에서 `▲ 이전 · ▼ 다음` 을 고릅니다.

## 웹 화면을 고쳤을 때

`web/index.html` 을 새 버전으로 바꾼 뒤 `npm run setup` 만 다시 실행하고 APK를 다시 빌드하세요.
(앱 안의 책·책갈피는 앱 데이터에 저장되므로, 같은 앱 ID(`com.chaekgyeol.reader`)로 덮어 설치하면 그대로 남습니다. 앱을 삭제하면 사라지니 먼저 **책갈피 › 백업&복구**로 백업해 두세요.)

## 구성

- `web/index.html` — 북 리더 화면 (웹 버전과 같은 파일)
- `native/ReaderNativePlugin.java` — 저장소 탐색·권한·볼륨키·알림줄·백업 저장
- `native/MainActivity.java` — 볼륨키를 가로채 웹 화면(`window.cgVolumeKey`)으로 전달
- `scripts/` — www 생성, 안드로이드 프로젝트에 네이티브 코드 넣기
- `.github/workflows/build-apk.yml` — GitHub에서 APK 자동 빌드

## 참고

- 이 프로젝트는 Capacitor 7 기준이며, 개발 환경 제약으로 실제 기기에서 시험하지 못한 상태로 만들어졌습니다. 빌드나 실행 중 오류가 나면 오류 메시지를 알려 주세요.
- 모든 파일 액세스(MANAGE_EXTERNAL_STORAGE) 권한을 쓰므로 Play 스토어 등록은 어렵고, 직접 설치(사이드로딩) 용도입니다.
- 저장소 안의 큰 파일(수십 MB 만화 ZIP)은 휴대폰 사양에 따라 여는 데 시간이 걸릴 수 있습니다.
