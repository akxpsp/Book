package com.chaekgyeol.reader;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.view.Window;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * 북 리더 전용 네이티브 기능 (웹 화면에서 ReaderNative 라는 이름으로 호출).
 *  - roots / listDir / readBase64 : 폰 저장소 폴더 탐색
 *  - allFilesStatus / requestAllFiles : "모든 파일 액세스" 권한
 *  - setVolumeNav : 볼륨키 페이지 넘기기 켜기/끄기 (MainActivity가 키를 가로챔)
 *  - setSystemBar : 상태표시줄(시스템 알림줄) 보이기/숨기기
 *  - saveText : 다운로드 폴더에 텍스트(백업 JSON) 저장
 */
@CapacitorPlugin(name = "ReaderNative")
public class ReaderNativePlugin extends Plugin {

    /** MainActivity.dispatchKeyEvent 가 읽는다. */
    public static volatile boolean volumeNav = false;

    private static JSObject entry(String name, String path) {
        JSObject o = new JSObject();
        o.put("name", name);
        o.put("path", path);
        return o;
    }

    @PluginMethod
    public void roots(PluginCall call) {
        JSArray roots = new JSArray();
        JSArray quick = new JSArray();
        File primary = Environment.getExternalStorageDirectory();
        roots.put(entry("내 저장공간", primary.getAbsolutePath()));
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                StorageManager sm = (StorageManager) getContext().getSystemService(Context.STORAGE_SERVICE);
                for (StorageVolume v : sm.getStorageVolumes()) {
                    if (v.isPrimary()) continue;
                    File d = v.getDirectory();
                    if (d != null && d.canRead()) {
                        String label = v.getDescription(getContext());
                        roots.put(entry(label != null ? label : "SD 카드", d.getAbsolutePath()));
                    }
                }
            }
        } catch (Exception ignored) { }
        String[][] q = {
            {"다운로드", Environment.DIRECTORY_DOWNLOADS},
            {"문서", Environment.DIRECTORY_DOCUMENTS},
            {"Books", "Books"},
        };
        for (String[] item : q) {
            File d = new File(primary, item[1]);
            if (d.isDirectory()) quick.put(entry(item[0], d.getAbsolutePath()));
        }
        JSObject r = new JSObject();
        r.put("roots", roots);
        r.put("quick", quick);
        call.resolve(r);
    }

    @PluginMethod
    public void listDir(PluginCall call) {
        String path = call.getString("path");
        if (path == null) { call.reject("path 가 필요합니다."); return; }
        File[] list = new File(path).listFiles();
        JSArray arr = new JSArray();
        if (list != null) {
            for (File f : list) {
                String n = f.getName();
                if (n.startsWith(".")) continue;
                JSObject o = new JSObject();
                o.put("name", n);
                o.put("path", f.getAbsolutePath());
                boolean dir = f.isDirectory();
                o.put("dir", dir);
                if (!dir) o.put("size", f.length());
                o.put("mtime", f.lastModified());
                arr.put(o);
            }
        }
        JSObject r = new JSObject();
        r.put("entries", arr);
        call.resolve(r);
    }

    /** 웹 화면이 파일을 직접 못 읽을 때만 쓰는 예비 경로 (큰 파일은 느림). */
    @PluginMethod
    public void readBase64(PluginCall call) {
        String path = call.getString("path");
        if (path == null) { call.reject("path 가 필요합니다."); return; }
        try (InputStream in = new FileInputStream(new File(path))) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            JSObject r = new JSObject();
            r.put("data", Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP));
            call.resolve(r);
        } catch (Exception e) {
            call.reject("파일을 읽을 수 없습니다: " + e.getMessage());
        }
    }

    @PluginMethod
    public void allFilesStatus(PluginCall call) {
        boolean granted;
        if (Build.VERSION.SDK_INT >= 30) {
            granted = Environment.isExternalStorageManager();
        } else {
            granted = ContextCompat.checkSelfPermission(getContext(),
                Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        }
        JSObject r = new JSObject();
        r.put("granted", granted);
        call.resolve(r);
    }

    @PluginMethod
    public void requestAllFiles(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                try {
                    Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getContext().getPackageName()));
                    getActivity().startActivity(i);
                } catch (Exception e) {
                    getActivity().startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                }
            } else {
                ActivityCompat.requestPermissions(getActivity(),
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 4242);
            }
            call.resolve();
        } catch (Exception e) {
            call.reject("권한 화면을 열 수 없습니다: " + e.getMessage());
        }
    }

    @PluginMethod
    public void setVolumeNav(PluginCall call) {
        volumeNav = Boolean.TRUE.equals(call.getBoolean("enabled", false));
        call.resolve();
    }

    @PluginMethod
    public void setSystemBar(PluginCall call) {
        final boolean visible = Boolean.TRUE.equals(call.getBoolean("visible", true));
        getActivity().runOnUiThread(() -> {
            try {
                Window w = getActivity().getWindow();
                WindowInsetsControllerCompat c = WindowCompat.getInsetsController(w, w.getDecorView());
                if (c == null) return;
                if (visible) {
                    c.show(WindowInsetsCompat.Type.statusBars());
                } else {
                    c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                    c.hide(WindowInsetsCompat.Type.statusBars());
                }
            } catch (Exception ignored) { }
        });
        call.resolve();
    }

    @PluginMethod
    public void saveText(PluginCall call) {
        String name = call.getString("name");
        String text = call.getString("text");
        if (name == null || text == null) { call.reject("name, text 가 필요합니다."); return; }
        byte[] data = text.getBytes(StandardCharsets.UTF_8);
        try {
            String where;
            if (Build.VERSION.SDK_INT >= 29) {
                ContentResolver cr = getContext().getContentResolver();
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new Exception("저장 위치를 만들 수 없습니다.");
                try (OutputStream os = cr.openOutputStream(uri)) {
                    if (os == null) throw new Exception("파일을 열 수 없습니다.");
                    os.write(data);
                }
                where = uri.toString();
            } else {
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                //noinspection ResultOfMethodCallIgnored
                dir.mkdirs();
                File out = new File(dir, name);
                try (FileOutputStream os = new FileOutputStream(out)) { os.write(data); }
                where = out.getAbsolutePath();
            }
            JSObject r = new JSObject();
            r.put("uri", where);
            call.resolve(r);
        } catch (Exception e) {
            call.reject("저장하지 못했습니다: " + e.getMessage());
        }
    }
}
