package com.chaekgyeol.reader;

import android.os.Bundle;
import android.view.KeyEvent;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(ReaderNativePlugin.class);
        super.onCreate(savedInstanceState);
    }

    /**
     * 볼륨키로 페이지 넘기기.
     * 책을 읽는 중(웹 화면이 setVolumeNav(true)를 보낸 동안)에만 볼륨키를 가로채서
     * 볼륨 올림 = 이전, 볼륨 내림 = 다음 신호를 웹 화면(window.cgVolumeKey)으로 보낸다.
     * 그 밖의 화면에서는 평소처럼 소리 크기가 조절된다.
     */
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int code = event.getKeyCode();
        if (ReaderNativePlugin.volumeNav
                && (code == KeyEvent.KEYCODE_VOLUME_UP || code == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                final String dir = code == KeyEvent.KEYCODE_VOLUME_UP ? "up" : "down";
                if (getBridge() != null && getBridge().getWebView() != null) {
                    getBridge().getWebView().post(() ->
                        getBridge().getWebView().evaluateJavascript(
                            "window.cgVolumeKey&&window.cgVolumeKey('" + dir + "')", null));
                }
            }
            return true; // 시스템 볼륨 조절 막기 (누름·뗌 모두)
        }
        return super.dispatchKeyEvent(event);
    }
}
