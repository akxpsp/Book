// `npx cap add android`로 만들어진 android/ 폴더에 북 리더 전용 네이티브 코드를 넣는다. (여러 번 실행해도 안전)
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const app = path.join(root, 'android', 'app');
const pkgDir = path.join(app, 'src', 'main', 'java', 'com', 'chaekgyeol', 'reader');

fs.mkdirSync(pkgDir, { recursive: true });
for (const f of ['MainActivity.java', 'ReaderNativePlugin.java']) {
  fs.copyFileSync(path.join(root, 'native', f), path.join(pkgDir, f));
}
// 다른 패키지에 만들어진 기본 MainActivity가 있으면 지운다 (중복 방지)
const javaRoot = path.join(app, 'src', 'main', 'java');
(function clean(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) clean(p);
    else if (e.name === 'MainActivity.java' && path.dirname(p) !== pkgDir) fs.rmSync(p);
  }
})(javaRoot);

// 매니페스트: 저장소 접근 권한
const mf = path.join(app, 'src', 'main', 'AndroidManifest.xml');
let x = fs.readFileSync(mf, 'utf8');
if (!x.includes('MANAGE_EXTERNAL_STORAGE')) {
  const perms =
    '    <uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE" />\n' +
    '    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />\n' +
    '    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />\n';
  x = x.replace(/(\s*<uses-permission android:name="android\.permission\.INTERNET"\s*\/>)/, '$1\n' + perms.trimEnd());
  if (!x.includes('MANAGE_EXTERNAL_STORAGE')) x = x.replace('</manifest>', perms + '</manifest>');
  fs.writeFileSync(mf, x);
}

// targetSdk 34: 안드로이드 15에서 화면이 상태표시줄 아래까지 강제로 늘어나는 것(엣지-투-엣지)을 피한다.
const vg = path.join(root, 'android', 'variables.gradle');
if (fs.existsSync(vg)) {
  let v = fs.readFileSync(vg, 'utf8');
  v = v.replace(/targetSdkVersion\s*=\s*\d+/, 'targetSdkVersion = 34');
  fs.writeFileSync(vg, v);
}

// 상태표시줄 색을 앱 배경과 맞춘다
const st = path.join(app, 'src', 'main', 'res', 'values', 'styles.xml');
if (fs.existsSync(st)) {
  let s = fs.readFileSync(st, 'utf8');
  if (!s.includes('windowLightStatusBar')) {
    s = s.replace(/(<style name="AppTheme\.NoActionBar"[^>]*>)/,
      '$1\n        <item name="android:statusBarColor">#eef1f0</item>\n        <item name="android:windowLightStatusBar">true</item>');
    fs.writeFileSync(st, s);
  }
}
console.log('android/ 패치 완료');
