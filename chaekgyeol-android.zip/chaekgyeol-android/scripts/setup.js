// 한 번에: www 만들기 → 안드로이드 프로젝트 생성(없을 때만) → 북 리더용 네이티브 코드 덮어쓰기 → 동기화
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const run = (cmd) => { console.log('> ' + cmd); execSync(cmd, { cwd: root, stdio: 'inherit' }); };

run('node scripts/build-www.js');
if (!fs.existsSync(path.join(root, 'android'))) run('npx cap add android');
run('node scripts/patch-android.js');
run('npx cap sync android');
console.log('\n준비 완료. APK 만들기:  cd android && ./gradlew assembleDebug');
