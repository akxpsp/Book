// web/index.html(북 리더 화면)을 앱용 www/ 폴더로 만든다.
// - 인터넷 없이도 되도록 JSZip·pdf.js를 앱 안에 넣는다.
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const www = path.join(root, 'www');
const mod = (...p) => path.join(root, 'node_modules', ...p);

let body = fs.readFileSync(path.join(root, 'web', 'index.html'), 'utf8');
const CDN = /<script src="https:\/\/cdnjs\.cloudflare\.com\/ajax\/libs\/jszip\/[^"]+"><\/script>/;
if (!CDN.test(body)) console.warn('경고: JSZip CDN 태그를 찾지 못했습니다. web/index.html을 확인하세요.');
body = body.replace(CDN, '<script src="lib/jszip.min.js"></script>');

const page = '<!doctype html>\n<html lang="ko">\n<head>\n<meta charset="utf-8">\n' +
  '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">\n' +
  '<meta name="theme-color" content="#eef1f0">\n</head>\n<body>\n' + body + '\n</body>\n</html>\n';

fs.rmSync(www, { recursive: true, force: true });
fs.mkdirSync(path.join(www, 'lib', 'pdfjs'), { recursive: true });
fs.writeFileSync(path.join(www, 'index.html'), page);
fs.copyFileSync(mod('jszip', 'dist', 'jszip.min.js'), path.join(www, 'lib', 'jszip.min.js'));
for (const f of ['pdf.min.mjs', 'pdf.worker.min.mjs']) {
  fs.copyFileSync(mod('pdfjs-dist', 'build', f), path.join(www, 'lib', 'pdfjs', f));
}
console.log('www/ 생성 완료');
